import httpx


def http_client(
    *,
    headers: dict[str, str] | None = None,
    proxy: str | None = None,
    follow_redirects: bool = False,
    base_url: str = "",
) -> httpx.Client:
    client_headers: dict[str, str] = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:147.0) Gecko/20100101 Firefox/147.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Origin": "https://www.facebook.com",
        "Alt-Used": "www.facebook.com",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "TE": "trailers",
    }
    client_cookies: dict[str, str] = {
        "datr": "emeOaIys3XO9UYWmzznuIGOI",
        "dpr": "2",
        "sb": "emeOaFqK-PSnP6OJi9GHlPaN",
        "wd": "1920x1080",
    }
    client_proxy: str | None = proxy or None

    return httpx.Client(
        headers=(client_headers | (headers or {})),
        cookies=client_cookies,
        proxy=client_proxy,
        timeout=15,
        http2=True,
        follow_redirects=follow_redirects,
        base_url=base_url,
    )
